
import quadtree

def test_insert_search():
    farm = quadtree.create_quadtree(0, 0, 100, 100)
    quadtree.insert(farm, (10, 10), {"moisture": 0.5})
    assert quadtree.search(farm, (10, 10))["moisture"] == 0.5

def test_delete():
    farm = quadtree.create_quadtree(0, 0, 100, 100)
    quadtree.insert(farm, (20, 30), {"moisture": 0.7})
    assert quadtree.delete(farm, (20, 30)) is True
    assert quadtree.search(farm, (20, 30)) is None