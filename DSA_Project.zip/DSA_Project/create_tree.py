def create_quadtree(x, y, width, height, max_depth=4, max_elements=4):
    """Initialize a quadtree node (as a dictionary)."""
    return {
        "x": x,
        "y": y,
        "width": width,
        "height": height,
        "max_depth": max_depth,
        "max_elements": max_elements,
        "depth": 0,
        "data": [],  # List of tuples: ( (x,y), {"moisture": 0.5, ...} )
        "children": None  # Will hold [nw, ne, sw, se] if subdivided
    }

def is_leaf(node):
    """Check if the node is a leaf (has no children)."""
    return node["children"] is None

def subdivide(node):
    """Split a node into 4 children (NW, NE, SW, SE)."""
    if node["depth"] >= node["max_depth"]:
        return False

    half_w = node["width"] / 2
    half_h = node["height"] / 2
    x, y = node["x"], node["y"]

    node["children"] = [
        create_quadtree(x, y, half_w, half_h, node["max_depth"], node["max_elements"]),
        create_quadtree(x + half_w, y, half_w, half_h, node["max_depth"], node["max_elements"]),
        create_quadtree(x, y + half_h, half_w, half_h, node["max_depth"], node["max_elements"]),
        create_quadtree(x + half_w, y + half_h, half_w, half_h, node["max_depth"], node["max_elements"])
    ]
    for child in node["children"]:
        child["depth"] = node["depth"] + 1
    return True

###############################################################################

farm = create_quadtree(x=0, y=0, width=100, height=100)  # 100x100 farm
print(farm)