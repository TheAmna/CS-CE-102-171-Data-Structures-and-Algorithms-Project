from create_tree import*

def insert(node, point, data):
    """
    Insert a data point into the quadtree.
    Returns: True if inserted, False if out of bounds.
    """
    px, py = point
    if not (node["x"] <= px < node["x"] + node["width"] and 
            node["y"] <= py < node["y"] + node["height"]):
        return False

    if is_leaf(node):
        node["data"].append( (point, data) )
        if len(node["data"]) > node["max_elements"] and node["depth"] < node["max_depth"]:
            subdivide(node)
            for p, d in node["data"]:
                for child in node["children"]:
                    insert(child, p, d)
            node["data"] = []
        return True
    else:
        for child in node["children"]:
            if insert(child, point, data):
                return True
    return False

###############################################################################

insert(farm, (10, 20), {"moisture": 0.6, "nutrients": {"N": 0.3, "P": 0.2, "K": 0.4}})