def get_stats(node):
    """Return aggregated stats (avg moisture, nutrients, etc.)."""
    if is_leaf(node):
        if not node["data"]:
            return None
        stats = {"moisture": 0, "temperature": 0, "nutrients": {"N": 0, "P": 0, "K": 0}}
        count = len(node["data"])
        for _, data in node["data"]:
            stats["moisture"] += data.get("moisture", 0)
            stats["temperature"] += data.get("temperature", 0)
            for nutrient in ["N", "P", "K"]:
                stats["nutrients"][nutrient] += data.get("nutrients", {}).get(nutrient, 0)
        stats["moisture"] /= count
        stats["temperature"] /= count
        for nutrient in ["N", "P", "K"]:
            stats["nutrients"][nutrient] /= count
        return stats
    else:
        child_stats = [get_stats(c) for c in node["children"] if get_stats(c) is not None]
        if not child_stats:
            return None
        stats = {"moisture": 0, "temperature": 0, "nutrients": {"N": 0, "P": 0, "K": 0}}
        for s in child_stats:
            stats["moisture"] += s["moisture"]
            stats["temperature"] += s["temperature"]
            for nutrient in ["N", "P", "K"]:
                stats["nutrients"][nutrient] += s["nutrients"][nutrient]
        stats["moisture"] /= len(child_stats)
        stats["temperature"] /= len(child_stats)
        for nutrient in ["N", "P", "K"]:
            stats["nutrients"][nutrient] /= len(child_stats)
        return stats
    

###############################################################################

print(get_stats(farm))  # Avg metrics for the entire farm