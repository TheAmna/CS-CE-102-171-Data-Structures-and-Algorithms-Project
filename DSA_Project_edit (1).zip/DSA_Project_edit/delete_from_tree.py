from create_tree import*

def delete(node, point):
    """
    Delete data at (x,y).
    Returns: True if deleted, False if not found.
    """
    px, py = point
    if not (node["x"] <= px < node["x"] + node["width"] and 
            node["y"] <= py < node["y"] + node["height"]):
        return False

    if is_leaf(node):
        for i, (p, _) in enumerate(node["data"]):
            if p == point:
                node["data"].pop(i)
                return True
        return False
    else:
        for child in node["children"]:
            if delete(child, point):
                # Merge children if all are leaves and total data <= max_elements
                if all(is_leaf(c) for c in node["children"]):
                    total_data = sum(len(c["data"]) for c in node["children"])
                    if total_data <= node["max_elements"]:
                        node["data"] = []
                        for c in node["children"]:
                            node["data"].extend(c["data"])
                        node["children"] = None
                return True
    return False



###############################################################################

delete(farm, (10, 20))  # Removes data at (10, 20)