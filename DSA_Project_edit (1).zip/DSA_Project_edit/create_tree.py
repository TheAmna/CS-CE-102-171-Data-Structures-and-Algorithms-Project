import csv
import ast

def create_quadtree_graph(n):
    """Create a quadtree graph with 2^n x 2^n resolution"""
    size = 2 ** n
    graph = {}
    
    def subdivide(x_min, y_min, x_max, y_max):
        node = ((x_min, y_min), (x_min, y_max), (x_max, y_min), (x_max, y_max))
        
        # BASE CASE : Stop subdivision at 1x1 cells
        if x_max - x_min == 1:
            graph[node] = []
            return
        
        mid_x = (x_min + x_max) // 2
        mid_y = (y_min + y_max) // 2
        
        children = [
            ((x_min, y_min), (x_min, mid_y), (mid_x, y_min), (mid_x, mid_y)),  # SW
            ((x_min, mid_y), (x_min, y_max), (mid_x, mid_y), (mid_x, y_max)),  # NW
            ((mid_x, y_min), (mid_x, mid_y), (x_max, y_min), (x_max, mid_y)),  # SE
            ((mid_x, mid_y), (mid_x, y_max), (x_max, mid_y), (x_max, y_max))   # NE
        ]
        
        graph[node] = children
        
        for child in children:
            subdivide(child[0][0], child[0][1], child[3][0], child[3][1])
    
    subdivide(0, 0, size, size)
    return graph

# EXAMPLE CASE IF n = 2
quadtree = create_quadtree_graph(2)  
for parent, children in quadtree.items():
    print(f"parent=  {parent}:")
    for child in children:
        print(f"child =  {child}")
    print()






# def create_quadtree(x, y, width, height, max_depth=4, max_elements=4):
#     """Initialize a quadtree node (as a dictionary).
#     Creates a dictionary representing a node with:
#     Boundary coordinates (x, y, width, height)
#     Configuration parameters (max_depth, max_elements)
#     Empty data list (for leaf nodes)
#     children set to None (will become a list of 4 sub-quadrants when split)"""


#     return {
#         "x": x,
#         "y": y,
#         "width": width,
#         "height": height,
#         "max_depth": max_depth,
#         "max_elements": max_elements,
#         "depth": 0,
#         "data": [],  # List of tuples: ( (x,y), {"moisture": 0.5, ...} )
#         "children": None  # Will hold [nw, ne, sw, se] if subdivided
#     }

# def parse_coordinates(coord_str):
#     """Convert string '(x,y)' to tuple (x,y)"""
#     # Remove parentheses
#     my_str = coord_str.strip()[1:-1]  # Turn "(1,2)" to "1,2"
#     x_str, y_str = my_str.split(",")
#     # Convert to numbers
#     x = float(x_str)
#     y = float(y_str)
#     return (x, y)

# def read_agriculture_data(filename):
#     """
#     Read agriculture data from CSV and process into quadtree format.
#     Returns: List of tuples (center_point, data_dict)
#     Opens CSV and reads rows as dictionaries
#     For each row:
#     Parses all 4 boundary coordinates
#     Calculates center point: Average of bottom_left and top_right
#     Extracts sensor data (moisture, pH, etc.)
#     Returns list of (center_point, data_dict) pairs
#     """
#     data_points = []
#     with open(filename, 'r') as file:
#         reader = csv.DictReader(file)
#         for row in reader:
#             # Calculate center point from the four coordinates
#             bl = parse_coordinates(row['bottom_left'])
#             tr = parse_coordinates(row['top_right'])
#             center_x = (bl[0] + tr[0]) / 2
#             center_y = (bl[1] + tr[1]) / 2
            
#             data = {
#                 "moisture": float(row['moisture']),
#                 "ph": float(row['ph']),
#                 "nutrients": int(row['nutrients']),
#                 "temperature": float(row['temperature']),
#                 "humidity": int(row['humidity'])
#             }
#             data_points.append(((center_x, center_y), data))
#     return data_points



###############################################################################

# qt = create_quadtree(2)  # 4x4 grid

# # Insert points
# insert(qt, (1, 1), {'temp': 27})  # SW quadrant
# insert(qt, (3, 3), {'temp': 30})  # NE quadrant
# print(qt)
# # Query the entire area
# print(query_range(qt, 0, 0, 4, 4))