from create_tree import*

def insert_agriculture_data(node, filename):
    """Insert all data from CSV file into quadtree
    Calls read_agriculture_data() to parse CSV

    For each data point:
    Calls insert() to place it in the correct quadrant
    insert(node, point, data)
    Purpose: Inserts a data point into the correct quadrant.
    Algorithm:
    Boundary Check: Verifies point is within node's area
    Leaf Node Handling:
    Adds data to node["data"]
    If exceeds max_elements, calls subdivide()
    Internal Node Handling:
    Recursively tries to insert into appropriate child quadrant"""

    data_points = read_agriculture_data(filename)
    for point, data in data_points:
        insert(node, point, data)

def insert(node, point, data):
    """
    Insert a data point into the quadtree.
    Returns: True if inserted, False if out of bounds.
    """
    px, py = point
    if not (node["x"] <= px < node["x"] + node["width"] and 
            node["y"] <= py < node["y"] + node["height"]):
        return False

    if node["children"] is None:
        node["data"].append((point, data))
        if len(node["data"]) > node["max_elements"] and node["depth"] < node["max_depth"]:
            subdivide(node)
            for p, d in node["data"]:
                for child in node["children"]:
                    insert(child, p, d)
            node["data"] = []
        return True
    else:
        for child in node["children"]:
            if insert(child, point, data):
                return True
    return False

def subdivide(node):
    """Split a node into 4 children ( equal sub-quadrants) (NW, NE, SW, SE)."""
    if node["depth"] >= node["max_depth"]:
        return False

    half_w = node["width"] / 2
    half_h = node["height"] / 2
    x, y = node["x"], node["y"]

    node["children"] = [
        create_quadtree(x, y, half_w, half_h, node["max_depth"], node["max_elements"]), # NW
        create_quadtree(x + half_w, y, half_w, half_h, node["max_depth"], node["max_elements"]), # NE
        create_quadtree(x, y + half_h, half_w, half_h, node["max_depth"], node["max_elements"]), # 
        create_quadtree(x + half_w, y + half_h, half_w, half_h, node["max_depth"], node["max_elements"])
    ]
    for child in node["children"]:
        child["depth"] = node["depth"] + 1
    return True
###############################################################################

