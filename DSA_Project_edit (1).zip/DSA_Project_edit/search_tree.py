from create_tree import*

def search(node, point):
    """
    Search for data at (x,y).
    Returns: Data dict if found, None otherwise.
    Checks if point is within current node's bounds
    If leaf node: Linear search through node["data"]
    If internal node: Recursively searches appropriate child
    """
    px, py = point
    if not (node["x"] <= px < node["x"] + node["width"] and 
            node["y"] <= py < node["y"] + node["height"]):
        return None

    if node["children"] is None:
        for p, data in node["data"]:
            if p == point:
                return data
        return None
    else:
        for child in node["children"]:
            result = search(child, point)
            if result is not None:
                return result
    return None

###############################################################################
