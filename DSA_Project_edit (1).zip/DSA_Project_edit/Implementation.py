from create_tree import*
from insert_tree import*
from search_tree import*

def get_stats(node):
    """Return aggregated stats for the quadrant
    Data Processing:
    Leaf Nodes:
    Sums all values in node["data"]
    Counts data points
    Calculates averages (except for nutrients which are summed)
    Internal Nodes:
    Recursively gets child stats
    Combines using weighted averages (by count)"""
    
    if node["children"] is None:
        if not node["data"]:
            return None
        
        stats = {
            "moisture": 0,
            "ph": 0,
            "nutrients": 0,
            "temperature": 0,
            "humidity": 0,
            "count": 0
        }
        
        for _, data in node["data"]:
            stats["moisture"] += data["moisture"]
            stats["ph"] += data["ph"]
            stats["nutrients"] += data["nutrients"]
            stats["temperature"] += data["temperature"]
            stats["humidity"] += data["humidity"]
            stats["count"] += 1
        
        # Calculate averages
        if stats["count"] > 0:
            for key in ["moisture", "ph", "temperature", "humidity"]:
                stats[key] /= stats["count"]
        
        return stats
    else:
        child_stats = [get_stats(child) for child in node["children"] if get_stats(child) is not None]
        if not child_stats:
            return None
            
        combined = {
            "moisture": 0,
            "ph": 0,
            "nutrients": 0,
            "temperature": 0,
            "humidity": 0,
            "count": 0
        }
        
        for s in child_stats:
            combined["moisture"] += s["moisture"] * s["count"]
            combined["ph"] += s["ph"] * s["count"]
            combined["nutrients"] += s["nutrients"]
            combined["temperature"] += s["temperature"] * s["count"]
            combined["humidity"] += s["humidity"] * s["count"]
            combined["count"] += s["count"]
        
        if combined["count"] > 0:
            for key in ["moisture", "ph", "temperature", "humidity"]:
                combined[key] /= combined["count"]
        
        return combined

# Example usage:
if __name__ == "__main__":
    # Initialize quadtree for a 16x16 farm (based on your CSV coordinates)
    farm = create_quadtree(0, 0, 16, 16)
    
    # Load data from CSV
    insert_agriculture_data(farm, "agriculture_data.csv")
    
    # Example queries
    print(search(farm, (7.5, 7.5)))  # Search center of the farm
    print(get_stats(farm))  # Get overall farm statistics
    

###############################################################################

print(get_stats(farm))  # Avg metrics for the entire farm